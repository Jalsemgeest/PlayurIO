var keyMirror = require('keymirror');

module.exports = keyMirror({
  SEARCH: null,
  ADD_SONG_BY_ID: null,
  SONG_CREATE: null,
  SONG_REMOVE: null,
  NEXT_SONG: null,
  GET_CURRENT_PLAYLIST:null,
  UPVOTE:null,
  DOWNVOTE:null
});